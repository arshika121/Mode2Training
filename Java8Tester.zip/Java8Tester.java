package com.arshu;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;

public class Java8Tester {

   public static void main(String args[]) {
      Java8Tester java8tester = new Java8Tester();
      java8tester.testLocalDateTime();
      java8tester.testBackwardCompatability();
   }
	
   public void testLocalDateTime() {
      // Get the current date and time
      LocalDateTime currentTime = LocalDateTime.now();
      System.out.println("Current DateTime: " + currentTime);
		
      LocalDate date1 = currentTime.toLocalDate();
      System.out.println("date1: " + date1);
		
      Month month = currentTime.getMonth();
      int day = currentTime.getDayOfMonth();
      int seconds = currentTime.getSecond();
		
      System.out.println("Month: " + month +"day: " + day +"seconds: " + seconds);
		
      LocalDateTime dateAndTime = currentTime.withDayOfMonth(10).withYear(2012);
      System.out.println("date2: " + dateAndTime);
		
      //12 december 2014
      LocalDate time3 = LocalDate.of(2014, Month.DECEMBER, 12);
      System.out.println("date3: " + time3);
		
      //22 hour 15 minutes
      LocalTime time4 = LocalTime.of(22, 15);
      System.out.println("date4: " + time4);
		
      //parse a string
      LocalTime time5 = LocalTime.parse("20:15:30");
      System.out.println("date5: " + time5);
      
      ZoneId currentZone = ZoneId.systemDefault();
      System.out.println("CurrentZone: " + currentZone);
      
      LocalDate today = LocalDate.now();
      System.out.println("Current date: " + today);

      LocalDate nextWeek = today.plus(1, ChronoUnit.WEEKS);
      System.out.println("Next week: " + nextWeek);
		
      //add 1 month to the current date
      LocalDate nextMonth = today.plus(1, ChronoUnit.MONTHS);
      System.out.println("Next month: " + nextMonth);
		
      //add 1 year to the current date
      LocalDate nextYear = today.plus(1, ChronoUnit.YEARS);
      System.out.println("Next year: " + nextYear);
		
      //add 10 years to the current date
      LocalDate nextDecade = today.plus(1, ChronoUnit.DECADES);
      System.out.println("Date after ten year: " + nextDecade);

   }
      public void testBackwardCompatability() {
         //Get the current date
         Date currentDate = new Date();
         System.out.println("Current date: " + currentDate);
   		
         //Get the instant of current date in terms of milliseconds
         Instant now = currentDate.toInstant();
         ZoneId currentZone = ZoneId.systemDefault();
   		
         LocalDateTime localDateTime = LocalDateTime.ofInstant(now, currentZone);
         System.out.println("Local date: " + localDateTime);
   		
         ZonedDateTime zonedDateTime = ZonedDateTime.ofInstant(now, currentZone);
         System.out.println("Zoned date: " + zonedDateTime);
      }

   }

