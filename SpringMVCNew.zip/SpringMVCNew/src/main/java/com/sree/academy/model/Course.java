package com.sree.academy.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="course")
public class Course {
@Id
Composite composite;

public Composite getComposite() {
	return composite;
}

public void setComposite(Composite composite) {
	this.composite = composite;
}

@Override
public String toString() {
	return "Course [composite=" + composite + "]";
}

}
