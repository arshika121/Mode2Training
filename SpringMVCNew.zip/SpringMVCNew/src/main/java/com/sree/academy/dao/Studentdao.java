package com.sree.academy.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sree.academy.model.Academy;
import com.sree.academy.model.College;
import com.sree.academy.model.Student;

@Repository
public class Studentdao {

	private static final Logger logger = LoggerFactory.getLogger(Studentdao.class);

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	public void saveUser(Student student, Academy academy) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(student);
		session.save(academy);
		logger.info("Student saved successfully, Student Details");
	}

	public College getPlace(Student student) {
		Session session = this.sessionFactory.getCurrentSession();
		String hql1 = "from Student  clg  where clg.USN = :collegeCode";
		List<College> result = session.createQuery(hql1).setString("collegeCode", student.getUSN()).list();
		if (result.size() != 0) {
			String str = student.getUSN().substring(0, 2);
			System.out.println(str);
			String hql = "from College  clg  where clg.collegeCode = :collegeCode";
			List<College> result1 = session.createQuery(hql).setString("collegeCode", str).list();
			System.out.println(result1.toString());
			return (College) result1.get(0);
		} else {
			return null;
		}
	}

	public List<Student> getAll(int id, int total) {
		String hql1 = "from Student";
		Session session = this.sessionFactory.getCurrentSession();
		Query query = session.createQuery(hql1);
		query.setFirstResult(id - 1);
		query.setMaxResults(total);
		List<Student> list = query.list();
		return list;
	}

	public List<Student> getPercentage() {
		Session session = this.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Student.class);
		criteria.add(Restrictions.gt("percentage", 30));
		List<Student> result = criteria.list();
		return result;
	}

}
