package com.sree.academy.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="college")
public class College {
String collegename;
@Id
String collegeCode;
String place;

public String getCollegeCode() {
	return collegeCode;
}
public void setCollegeCode(String collegeCode) {
	this.collegeCode = collegeCode;
}
public String getCollegename() {
	return collegename;
}
public void setCollegename(String collegename) {
	this.collegename = collegename;
}
public String getPlace() {
	return place;
}
public void setPlace(String place) {
	this.place = place;
}

}
