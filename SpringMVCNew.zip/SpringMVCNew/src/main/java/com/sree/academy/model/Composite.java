package com.sree.academy.model;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class Composite implements Serializable {
  String collegecode;
  String collegecourse;
public String getCollegecode() {
	return collegecode;
}
public void setCollegecode(String collegecode) {
	this.collegecode = collegecode;
}
public String getCollegecourse() {
	return collegecourse;
}
public void setCollegecourse(String collegecourse) {
	this.collegecourse = collegecourse;
}
  
}
