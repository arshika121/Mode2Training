package com.sree.academy.dao;



public interface  CoursesDao
{
	
}
