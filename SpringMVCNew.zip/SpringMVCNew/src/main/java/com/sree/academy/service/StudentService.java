package com.sree.academy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sree.academy.dao.Studentdao;
import com.sree.academy.model.Academy;
import com.sree.academy.model.College;
import com.sree.academy.model.Student;
import com.sree.academy.model.dto.StudentDto;

@Service // It is used to annotated classes which hold business logic in the Service
			// layer
public class StudentService {
	@Autowired
	Studentdao studentDao;

	@Transactional
	// This method is used to save the user details to the MySQL
	public void saveUser(Student student1, Academy academic) {
		studentDao.saveUser(student1, academic);
	}

	@Transactional

	// This method is used to get the place of the college from MySQL

	public College getPlace(Student student) {
		return studentDao.getPlace(student);

	}

	@Transactional
	// This method is used to get the list of students in the college from MySQL

	public List<Student> getAll(int id, int total) {
		return studentDao.getAll(id, total);
	}

	@Transactional
	
	// This method is used to get the list of student's percentage in the college from MySQL

	public List<Student> getPercentage() {
		return studentDao.getPercentage();
	}

}
