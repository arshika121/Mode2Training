package com.arshu;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class class3 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the number");
		int list = s.nextInt();

		List<Integer> list3 = new ArrayList<Integer>();
		for (int i = 0; i < list; i++) {
			list3.add(s.nextInt());

		}
		System.out.println(list3);
		
		 
		System.out.println("Enter the age");
		int list1 = s.nextInt();
		List<Integer> list4 = new ArrayList<Integer>();

		if(list1>18) {
			System.out.println(("valid"));
		}
		System.out.println("invalid");
        
				System.out.println("Enter the phone number");
		String str1 = s.nextLine();
		str1="9944027922";
		 List<String> list6 = new ArrayList<String>();

		if (str1.equals("9944027922") ){
			System.out.println("9944027922");
		}
		
		
		System.out.println("Enter the name"); 
		 String str=s.nextLine();
		 List<String> list5 = new ArrayList<String>();
		 if(str!=null) {
			 System.out.println(str);
		 }
	
		List<String> valid = list3.stream().map(p -> "SPI" + p).collect(Collectors.toList());
		System.out.println(valid);
		List<String> validAccount = valid.stream().filter(i -> i.length() == 8).collect(Collectors.toList());
		System.out.println("valid accounts are:");
		System.out.println(validAccount);
		List<String> InvalidAccount = valid.stream().filter(i -> i.length() != 8).collect(Collectors.toList());
		System.out.println("Invalid accounts are:");
		System.out.println(InvalidAccount);
		List<String>validate=list3.stream()
				 
				.map(x->"SBI"+x)
				 
				.filter(x->x.length()==8)

				.collect(Collectors.toList());
		List<String>invalidate=list3.stream()
				 
				.map(x->"SBI"+x)
				 
				.filter(x->x.length()!=8)

				.collect(Collectors.toList());
		System.out.println("valid accounts are:"+validAccount.size());

	}

}
