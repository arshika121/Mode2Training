package com.arshu;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;



public class Class6 {

	
	public static void main(String[] args) {
			
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the number");
		int list = s.nextInt();

		List<Integer> list3 = new ArrayList<Integer>();
		for (int i = 0; i < list; i++) {
			list3.add(s.nextInt());

		}
		List<String> valid = list3.stream().map(p -> "SBI" + p).collect(Collectors.toList());
		System.out.println(valid);
		List<String> validAccount = valid.stream().filter(i -> i.length() == 8).collect(Collectors.toList());
		System.out.println("valid accounts are:");
		System.out.println(validAccount);
		List<String> InvalidAccount = valid.stream().filter(i -> i.length() != 8).collect(Collectors.toList());
		System.out.println("Invalid accounts are:");
		System.out.println(InvalidAccount);
		System.out.println("valid accounts are:" + validAccount.size());
		System.out.println("enter the name, age, phoneNo, amount , balance");
		Customer[] c = new Customer[20];

		String nameList;

		int age;

		long phoneNo;

		String accNo;

		float amnt;

		float balance;

		List<Customer> listed = new ArrayList<Customer>();

		for (int i = 0; i < valid.size(); i++) {

			nameList = s.next();

			age = s.nextInt();

			phoneNo = s.nextLong();

			accNo = valid.get(i);

			amnt = s.nextFloat();

			balance = s.nextFloat();

			Customer cust = new Customer();

			c[i] = new Customer(nameList, age, phoneNo, accNo, balance);

			listed.add(c[i]);

		}

		List<Customer> res = listed.stream().filter(x -> x.name.matches("^[A-Z][a-zA-Z]{2,30}$") && (x.age > 18)
				&& (String.valueOf(x.phoneNo).matches("^[1-9][0-9]{2,10}$"))).collect(Collectors.toList());
		res.forEach((temp) -> {

			System.out.println("Name:" + temp.name + " " + "Age:" + temp.age + " " + "PhoneNo:" + temp.phoneNo + " "
					+ "AccNo:" + temp.accNo + "" + "balance:" + temp.balance);

		});
		List<Customer> sortedList = res.stream().sorted(Comparator.comparing(Customer::getName))

				.collect(Collectors.toList());

		System.out.println("Valid accounts are:");

		sortedList.forEach((temp) -> {

			System.out.println("Name:" + temp.name + " " + "Age:" + temp.age + " " + "PhoneNo:" + temp.phoneNo + " "
					+ "AccNo:" + temp.accNo + "" + "balance:" + temp.balance);

		});

		List<Customer> res1 = listed.stream().filter(x -> !(x.name.matches("^[A-Z][a-zA-Z]{2,30}$") && (x.age > 18)
				&& (String.valueOf(x.phoneNo).matches("^[1-9][0-9]{2,10}$")))).collect(Collectors.toList());

		System.out.println("Invalid accounts are:");

		res1.forEach((tem) -> {

			System.out.println("Name:" + tem.name + " " + "Age:" + tem.age + " " + "PhoneNo:" + tem.phoneNo + " "
					+ "AccNo:" + tem.accNo + "" + "balance:" + tem.balance);

		});

		int ch = 0;

		int flag = -1;

		System.out.println("Enter user name:");

		String CustomerName = s.next();

		for (int i = 0; i < res.size(); i++) {

			if (!(res.get(i).name.equals(CustomerName))) {

				flag = -1;

			}

			else {

				flag = i;

				break;

						}

		}

		if (flag == -1) {

			System.out.println("Invalid User..");
			System.out.println("your transaction was unsuccessful...Please try again!!!!");
		}

		Customer cust = new Customer();

		do {
			if (flag != -1) {

				System.out.println("Enter the choice:");

				System.out.println("1.Withdrawal");

				System.out.println("2.Deposit");

				System.out.println("3.MiniStatement");

				System.out.println("4.Exit");

				ch = s.nextInt();

				switch (ch) {

				case 1:

					cust.withdrawal(res, flag);

					break;

				case 2:

					cust.deposit(res, flag);

					break;

				case 3:

					cust.display(res, flag);

					break;

				case 4:

					System.out.println("Welcome..Please Visit us again!!!!!!!");

					break;

				default:

					System.out.println(ch + "which you entered is not Valid!!!!");

				}

			}
		} while (!(ch == 4));

	}
}

