package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Beneficiary")
public class Beneficiary {
	
	
	@Column(name = "cust_Id")
	private Integer cust_Id;
	@Id
	@Column(name = "baccNo")
	private String baccNo;
	@Column(name = "ifscCode")
	private String ifscCode;
	public Integer getCust_Id() {
		return cust_Id;
	}
	public void setCust_Id(Integer cust_Id) {
		this.cust_Id = cust_Id;
	}
	
	public String getBaccNo() {
		return baccNo;
	}
	public void setBaccNo(String baccNo) {
		this.baccNo = baccNo;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	
	
	
	

}
