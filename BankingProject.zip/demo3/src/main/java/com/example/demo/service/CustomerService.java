package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.AccountDao;
import com.example.demo.Dao.CustomerDao;
import com.example.demo.customerDto.CustomerDtoClass;
import com.example.demo.model.Account;
import com.example.demo.model.Customer;

@Service // It is used to annotated classes which hold business logic in the Service
//layer
public class CustomerService {
	@Autowired // This means to get the bean called customerDao
	private CustomerDao customerDao;

	@Autowired // This means to get the bean called accountdao
	private AccountDao accountDao;

	PasswordGeneration p = new PasswordGeneration();
	Account account = new Account();
	ModelMapper mapper = new ModelMapper();

	@Transactional
	// This method is used to add the customer details to the MySQL

	public String addCustomer(Customer customer) {

		customer.setCust_passwd(p.password());
		customer.setCust_id(p.cust_id());
		account.setCust_id(customer.getCust_id());
		account.setCust_acc(p.accNo());
		account.setBalance(5000000);

		if (customer.getCust_age() > 21) {
			if (!(String.valueOf(customer.getCust_phoneNo()).length() == 10)) {
				return "Please insert the valid phone number..";
			} else {
				customerDao.save(customer);
				accountDao.save(account);
				return "successfully registered...";
			}
		} else {
			return "you are not eligible";
		}

	}

	// This method is used to delete the customer details by cust_id from  MySQL

	public String deleteCustomer(Integer cust_id) {
		customerDao.deleteById(cust_id);
		accountDao.deleteById(cust_id);
		return "deleted successfully";
	}

	// This method is used to get the list of customer details from  MySQL

	List<CustomerDtoClass> list = new ArrayList<CustomerDtoClass>();

	public List<CustomerDtoClass> getAllCustomer() {
		customerDao.findAll().forEach(customer -> convertTo(customer));
		return list;
	}

	private void convertTo(Customer customer) {
		// TODO Auto-generated method stub
		list.add((mapper.map(customer, CustomerDtoClass.class)));
	}

	// This method is used to update the customer details from  MySQL

	public String updateCustomer(Integer cust_id, String email) {
		Customer customer = customerDao.findById(cust_id).orElse(null);

		if (null != customer) {
			customer.setCust_email(email);
		}
		customerDao.save(customer);
		return "successfully updated";
	}

	// This method is used to get the customer details by customer Id from MySQL

	public Customer getByCustomerId(Integer cust_id) {
		return customerDao.findById(cust_id).orElse(null);
	}

}
