package com.example.demo.service;

import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus
public class InsuffientBalance extends RuntimeException {
    	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		public InsuffientBalance(String exception) {
    		super(exception);
    }
}
