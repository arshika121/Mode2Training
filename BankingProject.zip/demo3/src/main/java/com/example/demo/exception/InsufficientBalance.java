package com.example.demo.exception;

import org.springframework.web.bind.annotation.ResponseStatus;
@ResponseStatus
public class InsufficientBalance extends RuntimeException {
    	public InsufficientBalance(String exception) {
    		super(exception);
    }
    
}
