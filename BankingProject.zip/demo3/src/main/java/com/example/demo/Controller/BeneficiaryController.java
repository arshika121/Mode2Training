package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Beneficiary;
import com.example.demo.service.BeneficiaryService;

@RestController
public class BeneficiaryController {

	@Autowired
	BeneficiaryService bs;

	@PostMapping("/b/add")
	public String addBeneficiary(@RequestBody Beneficiary beneficiary) {
		return bs.addBeneficiary(beneficiary);
	}

	@GetMapping(value = "/b/get/{ifscCode}")
	public Beneficiary getByIfscode(@PathVariable(value = "ifscCode") String ifscCode) {
		return bs.getByIfscode(ifscCode);

	}
}
