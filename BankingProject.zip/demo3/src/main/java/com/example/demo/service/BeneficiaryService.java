package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.BeneficiaryDAO;
import com.example.demo.model.Beneficiary;

@Service // It is used to annotated classes which hold business logic in the Service
//layer
public class BeneficiaryService {

	@Autowired // This means to get the bean called beneficiarydao
	BeneficiaryDAO beneficiarydao;

	// This method is used to add the beneficiary details to the MySQL

	public String addBeneficiary(Beneficiary beneficiary) {

		beneficiary.setCust_Id(beneficiary.getCust_Id());
		beneficiary.setBaccNo(beneficiary.getBaccNo());
		beneficiary.setIfscCode(beneficiary.getIfscCode());
		beneficiarydao.save(beneficiary);
		return "Successful";
	}

	// This method is used to get the IFSC code from MySQL

	public Beneficiary getByIfscode(String ifscCode) {
		return beneficiarydao.findAllByIfscCode(ifscCode);
	}
}
