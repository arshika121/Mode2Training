package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Transaction")
public class Transaction {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Integer TransactionId;
	
	@Column(name = "cust_id")
	private Integer cust_id;

	@Column(name = "cust_accno")
	private String cust_accno;
	
	@Column(name = "amount")
	private float amount;
	
	@Column(name = "transactionType")
	private String transactionType;
	
	@Column(name = "description")
	private String description;
	
	
	public Integer getTransactionId() {
		return TransactionId;
	}
	public void setTransactionId(Integer transactionId) {
		this.TransactionId = transactionId;
	}
	public String getCust_accno() {
		return cust_accno;
	}
	public void setCust_accno(String cust_accno) {
		this.cust_accno = cust_accno;
	}
	public Integer getCust_id() {
		return cust_id;
	}
	public void setCust_id(Integer cust_id) {
		this.cust_id = cust_id;
	}
	
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
}
