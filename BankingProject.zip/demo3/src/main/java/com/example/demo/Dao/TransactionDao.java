package com.example.demo.Dao;



import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Transaction;


@Repository
public interface TransactionDao extends PagingAndSortingRepository<Transaction, Integer> {
}
