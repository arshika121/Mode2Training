package com.springmvc.arshu.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.springmvc.arshu.model.CustomerDtoClass;
import com.springmvc.arshu.model.Movie;
import com.springmvc.arshu.service.ServiceClass;


//WelcomeController.java
@RestController          // This means that this class is a Controller

public class WelcomeController {

	@Autowired
	private ServiceClass serviceclass;  // This means to get the bean called serviceclass

	@RequestMapping("home")// This means URL's start with home (after Application path)
	public String home() {
		return "home";
	}

	@RequestMapping(value = "/customer/getAll",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)  // This means URL's start with /customer/getAll (after Application path)
	public List<CustomerDtoClass> getCustomer() {
		return serviceclass.getCustomer();
	}

	@RequestMapping(value = "/add/getAll",produces = MediaType.APPLICATION_JSON_VALUE,method = RequestMethod.GET)   // This means URL's start with /add/getAll (after Application path)
	public List<Movie> getMovie() {

		return serviceclass.getMovies();
	}

}
