package com.springmvc.arshu.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.springmvc.arshu.model.CustomerDtoClass;
import com.springmvc.arshu.model.Movie;


@Service //It is used to annotated classes which hold business logic in the Service layer
public class ServiceClass {
	
	public List<CustomerDtoClass> getCustomer()//This method is used to get all customer details from the MySQL
	{
		final String uri = "http://localhost:9092/customer/getAll";
		
		RestTemplate restTemplate = new RestTemplate();
		List<CustomerDtoClass> result = restTemplate.getForObject(uri, List.class);
		
		return result;
	}	    
	public  List<Movie> getMovies()  //This method is used to get all the movies form the MySQL
	{
		final String uri = "http://localhost:9091/add/getAll";
		
		RestTemplate restTemplate = new RestTemplate();
		List<Movie> result = restTemplate.getForObject(uri, List.class);
		
	
		return result;
	}	    }


