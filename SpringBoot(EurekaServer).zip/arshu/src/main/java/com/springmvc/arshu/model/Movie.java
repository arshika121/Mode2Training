package com.springmvc.arshu.model;

import java.time.LocalDate;

//Movie.Class

public class Movie {
	private String moviename;
	private String language;
	private LocalDate Releasingdate;

	public String getMoviename() {
		return moviename;
	}

	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public LocalDate getReleasingdate() {
		return Releasingdate;
	}

	public void setReleasingdate(LocalDate releasingdate) {
		Releasingdate = releasingdate;
	}

}
