package com.example.BookMyShow.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.BookMyShow.model.Theatre;
import com.example.BookMyShow.model.User;
import com.example.BookMyShow.service.Userservice;

@RestController   // This annotation is used to create RESTful web services
public class UserController {

	
	@Autowired   // This means to get the bean called userservice
	Userservice userservice;
	
	@PostMapping("/add/user")    // This means URL's start with /add/theatre (after Application path)
	public String addUser(@RequestBody User user) {
		return userservice.addUser(user);

}
}