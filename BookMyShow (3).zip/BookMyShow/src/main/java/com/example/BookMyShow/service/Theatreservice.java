package com.example.BookMyShow.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.BookMyShow.dao.Theatredao;
import com.example.BookMyShow.model.Theatre;

@Service // It is used to annotated classes which hold business logic in the Service
			// layer

public class Theatreservice {

	@Autowired // This means to get the bean called theatredao
	Theatredao theatredao;

	// This method is used to add the theatre into the MySQL
	public String addTheatre(Theatre theatre) {
		theatredao.save(theatre);
		return "theatre details has been added successfully";
	}

	// This method is used to get the list of theatres from MySQL
	public List<Theatre> find(String movieName) {

		List<Theatre> p = theatredao.find(movieName);

		return p;

	}

}
