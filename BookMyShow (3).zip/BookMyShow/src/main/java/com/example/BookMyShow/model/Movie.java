package com.example.BookMyShow.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Movie")
public class Movie {
@Id
@Column(name="Moviename")
private String moviename;
@Column(name="language")
private String language;
@Column(name="Releasingdate")
private LocalDate Releasingdate;

public String getMoviename() {
	return moviename;
}
public void setMoviename(String moviename) {
	this.moviename = moviename;
}
public String getLanguage() {
	return language;
}
public void setLanguage(String language) {
	this.language = language;
}
public LocalDate getReleasingdate() {
	return Releasingdate;
}
public void setReleasingdate(LocalDate releasingdate) {
	Releasingdate = releasingdate;
}

}
