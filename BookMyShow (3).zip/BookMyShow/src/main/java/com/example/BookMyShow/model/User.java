package com.example.BookMyShow.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "User")
public class User {

	@Column(name = "userphoneNo")
	private long userphoneNo;
	@Column(name = "username")
	private String username;
	@Column(name = "useremail")
	private String useremail;
	@Id
	@Column(name = "userId")
	private String userId;

	public long getUserphoneNo() {
		return userphoneNo;
	}

	public void setUserphoneNo(long userphoneNo) {
		this.userphoneNo = userphoneNo;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUseremail() {
		return useremail;
	}

	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
