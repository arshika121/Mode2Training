package com.example.BookMyShow.model;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Book")
public class Book {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
@Column(name="bookingId")
private Integer bookingId;
@Column(name="Bookingdate")
private LocalDate bookingdate;
@Column(name="Moviename")
private String moviename;
@Column(name="showtime")
private String showtime;
@Column(name="theatrename")
private String theatrename;
@Column(name="userId")
private int userId;

public LocalDate getBookingdate() {
	return bookingdate;
}
public void setBookingdate(LocalDate bookingdate) {
	this.bookingdate = bookingdate;
}
public String getMoviename() {
	return moviename;
}
public void setMoviename(String moviename) {
	this.moviename = moviename;
}
public String getTheatrename() {
	return theatrename;
}
public void setTheatrename(String theatrename) {
	this.theatrename = theatrename;
}
public String getShowtime() {
	return showtime;
}
public void setShowtime(String showtime) {
	this.showtime = showtime;
}
public Integer getBookingId() {
	return bookingId;
}
public void setBookingId(Integer bookingId) {
	this.bookingId = bookingId;
}
public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}








}
