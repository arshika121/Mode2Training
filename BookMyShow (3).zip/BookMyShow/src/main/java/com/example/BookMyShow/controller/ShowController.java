package com.example.BookMyShow.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.BookMyShow.dto.showdto;
import com.example.BookMyShow.model.Show;
import com.example.BookMyShow.model.newClass;
import com.example.BookMyShow.service.Showservice;

@RestController   //This annotation is used to create RESTful web services 
public class ShowController {

	
	@Autowired     // This means to get the bean called showservice
	Showservice showservice;
	@PostMapping("/add/show")  // This means URL's start with /add/show (after Application path)
	public String addShow(@RequestBody Show show) {
		return showservice.addShow(show);
	}
	
	@PostMapping(value="/add/show/search")  // This means URL's start with /add/show/search (after Application path)
	public String checkMovie(@RequestBody showdto showdt)/* throws IOException */{
		String string=showservice.checkMovie(showdt);
		return string;
	}
	
	@GetMapping(value="/add/show/{moviename}")   // This means URL's start with /add/show/{moviename} (after Application path)
	public List<newClass> getMovie(@PathVariable String moviename) {
		List<newClass> p = showservice.showlist(moviename);
		return p;
		
	
		
	}
}
