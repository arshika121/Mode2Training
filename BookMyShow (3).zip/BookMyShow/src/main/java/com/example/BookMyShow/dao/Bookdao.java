package com.example.BookMyShow.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.BookMyShow.model.Book;
import com.example.BookMyShow.model.Show;

@Repository
public interface Bookdao extends CrudRepository<Book,String> {
	  @Query(value="select * from Book s where s.morningshow=?1 or s.noonshow=?1 or s.eveningshow=?1",nativeQuery=true)
		List<Book> findByMovieName(String moviename);

}
