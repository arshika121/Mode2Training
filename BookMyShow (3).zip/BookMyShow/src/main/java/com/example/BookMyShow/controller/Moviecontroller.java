package com.example.BookMyShow.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.BookMyShow.model.Movie;
import com.example.BookMyShow.model.Theatre;
import com.example.BookMyShow.service.Movieservice;

@RestController    //This annotation is used to create RESTful web services  
public class Moviecontroller {

	@Autowired   // This means to get the bean called movieservice
	Movieservice movieservice;

	@PostMapping("/add/Movie")    // This means URL's start with /add/Movie (after Application path)

	public String addMovie(@RequestBody Movie movie) {
		return movieservice.addMovie(movie);
	}

	@GetMapping(value = "/add/getAll") // This means URL's start with /add/getAll (after Application path)
	public List<Movie> getAllCustomer() {
		return movieservice.getAllMovie();

	}
}