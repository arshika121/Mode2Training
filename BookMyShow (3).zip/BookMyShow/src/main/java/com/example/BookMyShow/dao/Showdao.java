package com.example.BookMyShow.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.BookMyShow.model.Movie;
import com.example.BookMyShow.model.Show;

@Repository
public interface Showdao extends CrudRepository<Show, String> {

	@Query(value = "select * from Showtable s where s.morningshow=?1 or s.noonshow=?1 or s.eveningshow=?1", nativeQuery = true)

	List<Show> findByMovieName(String moviename);

	}
