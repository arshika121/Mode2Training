package com.example.BookMyShow.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Showtable")
public class Show {
@Id
@Column(name="ShowId")
private String ShowId;
@Column(name="TheatreId")
private String TheatreId;
@Column(name="showdate")
private LocalDate showdate;
@Column(name="morningshow")
private String morningshow;
@Column(name="noonshow")
private String noonshow;
@Column(name="eveningshow")
private String eveningshow;


public String getShowId() {
	return ShowId;
}
public void setShowId(String showId) {
	ShowId = showId;
}
public String getTheatreId() {
	return TheatreId;
}
public void setTheatreId(String theatreId) {
	TheatreId = theatreId;
}
public LocalDate getShowdate() {
	return showdate;
}
public void setShowdate(LocalDate showdate) {
	this.showdate = showdate;
}
public String getMorningshow() {
	return morningshow;
}
public void setMorningshow(String morningshow) {
	this.morningshow = morningshow;
}
public String getNoonshow() {
	return noonshow;
}
public void setNoonshow(String noonshow) {
	this.noonshow = noonshow;
}
public String getEveningshow() {
	return eveningshow;
}
public void setEveningshow(String eveningshow) {
	this.eveningshow = eveningshow;
}





}
