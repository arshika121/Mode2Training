package com.example.BookMyShow.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.BookMyShow.dao.Moviedao;
import com.example.BookMyShow.model.Movie;

@Service  // It is used to annotated classes which hold business logic in the Service
              // layer
public class Movieservice {

	
	@Autowired   // This means to get the bean called moviedao
	Moviedao moviedao;
	ModelMapper mapper = new ModelMapper();

	//This method is used to add movie details to the MySQL
	
	public String addMovie(Movie movie) {
		moviedao.save(movie);
		return "Moviedetails has been added successfully";
	}
	
	//This method is used to get the list of movies from the MySQL
	
	List<Movie> list=new ArrayList<Movie>();

	public List<Movie> getAllMovie() {
		moviedao.findAll().forEach(movie->convertTo(movie));
		return list;

	
	}
	
	private void convertTo(Movie movie) {
		list.add((mapper.map(movie, Movie.class)));
	}




}
