package com.example.BookMyShow.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Theatre")
public class Theatre {
	@Id
	@Column(name = "TheatreId")
	private String TheatreId;
	@Column(name = "theatrename")
	String theatrename;
	@Column(name = "theatreplace")
	String theatreplace;

	public String getTheatreId() {
		return TheatreId;
	}

	public void setTheatreId(String theatreId) {
		TheatreId = theatreId;
	}

	public String getTheatrename() {
		return theatrename;
	}

	public void setTheatrename(String theatrename) {
		this.theatrename = theatrename;
	}

	public String getTheatreplace() {
		return theatreplace;
	}

	public void setTheatreplace(String theatreplace) {
		this.theatreplace = theatreplace;
	}

}
