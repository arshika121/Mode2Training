package com.example.BookMyShow.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.BookMyShow.model.User;
@Repository
public interface Userdao extends CrudRepository<User,String>{

}
