package com.example.BookMyShow.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.BookMyShow.model.Book;
import com.example.BookMyShow.model.Movie;
import com.example.BookMyShow.service.Bookservice;

@RestController  //This annotation is used to create RESTful web services

public class Bookcontroller {

	@Autowired  // This means to get the bean called bookservice
	Bookservice bookservice;

	@PostMapping(value = "/add/booking")

	public Book addShowDetails(@RequestParam String moviename, @RequestParam String TheatreId,
			@RequestParam String showtime, @RequestParam int userId) {

		return (Book) bookservice.addBooking(moviename, TheatreId, showtime, userId);

	}
}
