package com.example.BookMyShow.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.BookMyShow.model.Theatre;
import com.example.BookMyShow.model.newClass;
@Repository
public interface Theatredao extends CrudRepository<Theatre,String>{
	
	
	  @Query(value="select * from Theatre t where t.theatre_id IN (select s.theatre_id from Showtable s where s.morningshow=?1 or s.noonshow=?1 or s.eveningshow=?1)",nativeQuery=true)
	  
	  public List<Theatre> find(String moviename); 

	 
}
