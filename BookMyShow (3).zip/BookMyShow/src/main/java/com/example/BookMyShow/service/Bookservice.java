package com.example.BookMyShow.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.BookMyShow.dao.Bookdao;
import com.example.BookMyShow.dao.Showdao;
import com.example.BookMyShow.dao.Theatredao;
import com.example.BookMyShow.model.Book;
import com.example.BookMyShow.model.Show;
import com.example.BookMyShow.model.Theatre;

@Service // It is used to annotated classes which hold business logic in the Service
			// layer
public class Bookservice {

	@Autowired // This means to get the bean called bookdao
	Bookdao bookdao;

	@Autowired // This means to get the bean called theatredao

	Theatredao theatredao;

	@Autowired // This means to get the bean called showdao

	Showdao showdao;

	// This method is used to add the booking details
	
	public Book addBooking(String moviename, String TheatreId, String showtime, int userId) {

		Theatre theatre = theatredao.findById(TheatreId).orElse(null);

		Show show = showdao.findById(TheatreId).orElse(null);

		Book b = new Book();

		b.setUserId(userId);

		b.setShowtime(showtime);

		b.setMoviename(moviename);

		b.setTheatrename(theatre.getTheatrename());

		b.setBookingdate(LocalDate.now());

		return bookdao.save(b);

	}

}
