package com.example.BookMyShow.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.BookMyShow.dao.Userdao;
import com.example.BookMyShow.model.User;

@Service  // It is used to annotated classes which hold business logic in the Service
// layer
public class Userservice {

	
	@Autowired    // This means to get the bean called userdao
	Userdao userdao;
	
	// This method is used to add the user into the MySQL

	public String addUser(User user) {
		// TODO Auto-generated method stub
		userdao.save(user);
		return "user details has been added successfully";
	
	
	}

}
