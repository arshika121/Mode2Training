package com.example.BookMyShow.dto;

public class showdto {
	private String showfind;

	public String getShowfind() {
		return showfind;
	}

	public void setShowfind(String showfind) {
		this.showfind = showfind;
	}

}
