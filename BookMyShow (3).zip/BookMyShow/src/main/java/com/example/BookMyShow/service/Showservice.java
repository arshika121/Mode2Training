package com.example.BookMyShow.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.BookMyShow.dao.Showdao;
import com.example.BookMyShow.dao.Theatredao;
import com.example.BookMyShow.dto.showdto;
import com.example.BookMyShow.exception.MovieNotFound;
import com.example.BookMyShow.model.Show;
import com.example.BookMyShow.model.Theatre;
import com.example.BookMyShow.model.newClass;

@Service // It is used to annotated classes which hold business logic in the Service
// layer

public class Showservice {

	@Autowired // This means to get the bean called showdao
	Showdao showdao;

	@Autowired // This means to get the bean called theatredao
	Theatredao theatredao;

	// This method is used to add the show into the MySQL
	public String addShow(Show show) {
		showdao.save(show);
		return "Show details has been added successfully";

	}

	// This method is used to get the check for the movies from the MySQL

	public String checkMovie(showdto showdt) {
		int flag = 0;
		List<Show> list = (List<Show>) showdao.findAll();
		for (Show show : list) {
			if (showdt.getShowfind().equalsIgnoreCase(show.getMorningshow())
					|| showdt.getShowfind().equalsIgnoreCase(show.getNoonshow())
					|| showdt.getShowfind().equalsIgnoreCase(show.getEveningshow())) {
				flag = 1;
				return "Movie Exist";
			}
		}
		if (flag == 0) {
			throw new MovieNotFound("Movie doesn't exists");
		}
		return null;
	}

	// This method is used to get the list of shows from the MySQL

	public List<newClass> showlist(String moviename) {
		List<Show> listshow = showdao.findByMovieName(moviename);
		Theatre t1 = new Theatre();
		List<newClass> list = new ArrayList<>();

		for (Show show : listshow) {
			newClass newclass = new newClass();
			String theatre_Id = show.getTheatreId();
			t1 = theatredao.findById(theatre_Id).orElse(null);
			newclass.setTheatreplace(t1.getTheatreplace());
			newclass.setTheatrename(t1.getTheatrename());
			newclass.setMorningshow(show.getMorningshow());
			newclass.setNoonshow(show.getNoonshow());
			newclass.setEveningshow(show.getEveningshow());
			list.add(newclass);

		}

		return list;

	}

}
