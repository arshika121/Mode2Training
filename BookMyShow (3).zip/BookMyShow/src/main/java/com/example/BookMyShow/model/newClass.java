package com.example.BookMyShow.model;

public class newClass {
	private String theatrename;
	private String theatreplace;
	private String morningshow;
	private String noonshow;
	private String eveningshow;

	public String getMorningshow() {
		return morningshow;
	}

	public void setMorningshow(String morningshow) {
		this.morningshow = morningshow;
	}

	public String getNoonshow() {
		return noonshow;
	}

	public void setNoonshow(String noonshow) {
		this.noonshow = noonshow;
	}

	public String getEveningshow() {
		return eveningshow;
	}

	public void setEveningshow(String eveningshow) {
		this.eveningshow = eveningshow;
	}

	public String getTheatrename() {
		return theatrename;
	}

	public void setTheatrename(String theatrename) {
		this.theatrename = theatrename;
	}

	public String getTheatreplace() {
		return theatreplace;
	}

	public void setTheatreplace(String theatreplace) {
		this.theatreplace = theatreplace;
	}

}
