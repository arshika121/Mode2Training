package com.arshu;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class class1 {

	int a;
	String name;

	public class1(int a, String name) {
		super();
		this.a = a;
		this.name = name;
	}

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

		list.stream()

				.filter(n -> n % 2 == 0).distinct().peek(e -> System.out.println("Filtered value: " + e))
				.forEach(System.out::println);

		List<String> list1 = Arrays.asList("bob", "Sue", "Harry", "Stephen");
		list1.stream()

				.filter(s -> s.isEmpty())

				.forEach(System.out::println);

		List<Integer> list5 = Arrays.asList(1, 2, 3);

		List<Integer> list2 = Arrays.asList(4, 5, 6);

		List<Integer> list3 = Arrays.asList(7, 8, 9);

		List<List<Integer>> listOfLists = Arrays.asList(list5, list2, list3);

		List<Integer> listOfAllIntegers = listOfLists.stream()

				.flatMap(x -> x.stream())

				.collect(Collectors.toList());

		System.out.println(listOfAllIntegers);

		Stream<Integer> stream = Stream.of(5, 6, 7, 8, 9, 10);

		// Using Stream toArray()
		Object[] arr = stream.toArray();

		// Displaying the elements in array arr
		System.out.println(Arrays.toString(arr));

		List<Integer> list6 = Arrays.asList(0, 2, 4, 6, 8, 10, 12);

		// Using count() to count the number
		// of elements in the stream and
		// storing the result in a variable.
		long total = list6.stream().count();

		// Displaying the number of elements
		System.out.println(total);

		List<Integer> list7 = Arrays.asList(-9, -18, 0, 25, 4);

		// Using stream.min() to get minimum
		// element according to provided Integer Comparator
		Integer var = list7.stream().min(Integer::compare).get();
		System.out.print("The minimum value is : ");
		System.out.println(var);

		List<Integer> list8 = Arrays.asList(-9, -18, 0, 25, 4);

		System.out.print("The maximum value is : ");

		// Using stream.max() to get maximum
		// element according to provided Comparator
		// and storing in variable var
		Integer var1 = list8.stream().max(Integer::compare).get();

		System.out.println(var);

		List<Integer> list9 = Arrays.asList(3, 4, 6, 12, 20);

		// Stream anyMatch(Predicate predicate)
		boolean answer = list9.stream().anyMatch(n -> (n * (n + 1)) / 4 == 5);

		// Displaying the result
		System.out.println(answer);
		List<String> words = Arrays.asList("GFG", "Geeks", "for", "GeeksQuiz", "GeeksforGeeks");

          // The lambda expression passed to 
          // reduce() method takes two Strings 
          // and returns the the longer String. 
          // The result of the reduce() method is 
         // an Optional because the list on which 
         // reduce() is called may be empty. 
		Optional<String> longestString = words.stream()
				.reduce((word1, word2) -> word1.length() > word2.length() ? word1 : word2);

// Displaying the longest String 
		longestString.ifPresent(System.out::println);

	}

}

