package com.springmvc.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;

import com.springmvc.dao.customerDAO;
import com.springmvc.model.Customer;

public class customerService {

	@Autowired    // This means to get the bean called cust
	private customerDAO cust;

	
	   @Transactional //this method is used to insert customer details in MySQL
	public void save(Customer customer) {
            
		cust.insert(customer);
	
	}
  
	
   @Transactional  //this method is used to fetch customer details from MySQL
	public List<Customer> listPersons() {
		return cust.getAll();
		
		
		
	}

}
