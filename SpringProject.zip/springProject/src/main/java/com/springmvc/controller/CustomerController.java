package com.springmvc.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.springmvc.dao.customerDAO;
import com.springmvc.model.Customer;
import com.springmvc.service.customerService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//CustomerController.java

@Controller  // This means that this class is a Controller
public class CustomerController {
	@Autowired   // This means to get the bean called customerservice
	customerService customerservice;

	private Map<String, Customer> USER = null;

	public CustomerController() {
		USER = new HashMap<String, Customer>();
	}

	List<Customer> l1 = new ArrayList<Customer>();
	
	
	@RequestMapping(value = "/USER/success", method = RequestMethod.GET)	// This means URL's start with /USER/success (after Application path)

	public String saveEmployeePage(Model model) {
		model.addAttribute("USER", new Customer());
		return "registration";
	}
	

	@RequestMapping(value = "/USER/add.do", method = RequestMethod.POST)	// This means URL's start with /USER/add.do (after Application path)

	public String saveEmployeeAction(@ModelAttribute("Customer") @Validated Customer customer,
			BindingResult bindingResult, Model model) {

		if (bindingResult.hasErrors()) {
			return "registration";

		}
		model.addAttribute("USER", customer);
		customerservice.save(customer);
		customerservice.listPersons();
		return "home";
	}

}
