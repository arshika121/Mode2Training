package com.springmvc.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.springmvc.model.Customer;

public class customerDAO  {
	private SessionFactory sessionFactory;
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
  @Transactional //Here we are inserting all the customer details in MySQL
	public void insert(Customer customer) {
	  System.out.println("Hi");
	  Session session=this.sessionFactory.openSession();
	  System.out.println("Welcome");
		Transaction tx=session.beginTransaction();
		session.persist(customer);
		tx.commit();
	session.close();
	}
  @Transactional   //Here we fetching all the customer details in MySQL
	public List<Customer> getAll() {
	  Session session=this.sessionFactory.openSession();
	  List<Customer> List = session.createQuery("from Customer").list();
		session.close();
		return List;

	}
 	

}
