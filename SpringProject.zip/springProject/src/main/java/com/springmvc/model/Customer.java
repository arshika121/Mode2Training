package com.springmvc.model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.GenericGenerator;

@Entity  // This tells Hibernate to make a table out of this class
@Table(name = "bank")   //This will create table in MySQL
public class Customer {
	@Id
	
	  @GeneratedValue(generator="increment")
	  
	  @GenericGenerator(name="increment",strategy="increment")
	 

	@Column(name = "customerId")

	private int customerId;

   	@Column(name = "name")
	private String name;
	@NotNull
	@Column(name = "age")
	private int age;
	@NotNull
	@Column(name = "phoneNo")
	private long phoneNo;
	@NotNull
	@Column(name = "email")
	private String email;
	@NotNull
	@Column(name = "job")
	private String job;
	@GeneratedValue(generator="increment")
	@GenericGenerator(name="increment",strategy="increment")
	@Column(name = "accNo")
	private String accNo;
	@GeneratedValue(generator="increment")
	@GenericGenerator(name="increment",strategy="increment")
	@Column(name = "password")
	private String password;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getAccNo() {
		return accNo;
	}

	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", name=" + name + ", age=" + age + ", phoneNo=" + phoneNo
				+ ", email=" + email + ", job=" + job + ", accNo=" + accNo + ", password=" + password + "]";
	}

	

}
